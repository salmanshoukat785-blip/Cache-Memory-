package com.sdcachemanager.domain

import java.io.IOException
import java.util.Locale
import kotlin.coroutines.cancellation.CancellationException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class DomainHelpersTest {

    @Before
    fun setUp() {
        Locale.setDefault(Locale.US)
    }

    // ---- formatBytes

    @Test
    fun formatBytes_smallValuesAreInBytes() {
        assertEquals("0 B", formatBytes(0))
        assertEquals("1023 B", formatBytes(1023))
    }

    @Test
    fun formatBytes_usesBinaryUnits() {
        assertEquals("1.0 KB", formatBytes(1024))
        assertEquals("1.5 MB", formatBytes(1_572_864))
        assertEquals("2.0 GB", formatBytes(2L * 1024 * 1024 * 1024))
    }

    // ---- StorageInfo

    @Test
    fun storageInfo_computesUsedAndFraction() {
        val info = StorageInfo(totalBytes = 1000, freeBytes = 250)
        assertEquals(750, info.usedBytes)
        assertEquals(0.75f, info.usedFraction, 0.0001f)
    }

    @Test
    fun storageInfo_unknownTotalHasZeroFraction() {
        assertEquals(0f, StorageInfo.UNKNOWN.usedFraction, 0f)
    }

    @Test
    fun storageInfo_neverNegative() {
        val info = StorageInfo(totalBytes = 100, freeBytes = 500)
        assertEquals(0, info.usedBytes)
    }

    // ---- error mapping

    @Test
    fun securityExceptionMapsToPermissionLost() {
        assertSame(AppError.PermissionLost, SecurityException("revoked").toAppError())
    }

    @Test
    fun noSpaceIoExceptionMapsToStorageFull() {
        assertSame(AppError.StorageFull, IOException("write failed: ENOSPC (No space left on device)").toAppError())
    }

    @Test
    fun otherIoExceptionMapsToIoFailure() {
        val error = IOException("disk error").toAppError()
        assertTrue(error is AppError.IoFailure)
        assertEquals("disk error", error.message)
    }

    // ---- cacheRunCatching

    @Test
    fun cacheRunCatching_wrapsSuccess() {
        val result = cacheRunCatching { 42 }
        assertEquals(CacheResult.Success(42), result)
        assertEquals(42, result.getOrNull())
    }

    @Test
    fun cacheRunCatching_wrapsFailure() {
        val result = cacheRunCatching<Int> { throw SecurityException("nope") }
        assertSame(AppError.PermissionLost, result.errorOrNull())
    }

    @Test
    fun cacheRunCatching_rethrowsCancellation() {
        try {
            cacheRunCatching<Unit> { throw CancellationException("cancelled") }
            fail("CancellationException must not be swallowed")
        } catch (expected: CancellationException) {
            // correct: structured concurrency keeps working
        }
    }

    @Test
    fun map_transformsSuccessAndKeepsFailure() {
        assertEquals(CacheResult.Success(4), CacheResult.Success(2).map { it * 2 })
        val failure: CacheResult<Int> = CacheResult.Failure(AppError.SdCardUnavailable)
        assertSame(failure, failure.map { it * 2 })
    }
}
