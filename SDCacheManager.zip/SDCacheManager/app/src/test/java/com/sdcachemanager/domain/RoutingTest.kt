package com.sdcachemanager.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RoutingTest {

    private val enabled = AppSettings(sdCacheEnabled = true, folderUri = "content://tree/1A2B-3C4D%3ACache")
    private val disabled = enabled.copy(sdCacheEnabled = false)

    private val cardOk = SdCardStatus.Available(
        SdVolume(label = "SD card", uuid = "1A2B-3C4D", storage = StorageInfo(1000, 400))
    )
    private val cardReadOnly = SdCardStatus.Unusable("SD card", "The card is read-only.")

    private val folderReady = CacheFolderState.Ready("content://tree/1A2B-3C4D%3ACache", "Cache", "1A2B-3C4D")

    @Test
    fun usesSdCardWhenEverythingIsReady() {
        val routing = resolveRouting(enabled, cardOk, folderReady)
        assertEquals(StorageMode.SD_CARD, routing.mode)
        assertNull(routing.fallbackReason)
        assertFalse(routing.isFallback)
    }

    @Test
    fun usesInternalWhenDisabledByUser_evenIfCardIsReady() {
        val routing = resolveRouting(disabled, cardOk, folderReady)
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.DISABLED_BY_USER, routing.fallbackReason)
        assertTrue(routing.isFallback)
    }

    @Test
    fun fallsBackWhenCardIsRemoved() {
        val routing = resolveRouting(enabled, SdCardStatus.NotDetected, folderReady)
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.SD_CARD_MISSING, routing.fallbackReason)
    }

    @Test
    fun fallsBackWhenCardIsReadOnly() {
        val routing = resolveRouting(enabled, cardReadOnly, folderReady)
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.SD_CARD_UNUSABLE, routing.fallbackReason)
    }

    @Test
    fun fallsBackWhenNoFolderSelected() {
        val routing = resolveRouting(enabled.copy(folderUri = null), cardOk, CacheFolderState.NotSelected)
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.NO_FOLDER_SELECTED, routing.fallbackReason)
    }

    @Test
    fun fallsBackWhenPermissionIsLost() {
        val routing = resolveRouting(enabled, cardOk, CacheFolderState.PermissionLost("content://x"))
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.PERMISSION_LOST, routing.fallbackReason)
    }

    @Test
    fun fallsBackWhenFolderIsUnreachable() {
        val routing = resolveRouting(enabled, cardOk, CacheFolderState.Unreachable("content://x", "gone"))
        assertEquals(StorageMode.INTERNAL, routing.mode)
        assertEquals(FallbackReason.FOLDER_UNREACHABLE, routing.fallbackReason)
    }

    @Test
    fun switchesBackToSdCardWhenItReturns() {
        val removed = resolveRouting(enabled, SdCardStatus.NotDetected, folderReady)
        val back = resolveRouting(enabled, cardOk, folderReady)
        assertEquals(StorageMode.INTERNAL, removed.mode)
        assertEquals(StorageMode.SD_CARD, back.mode)
    }

    @Test
    fun userSettingWinsOverCardState() {
        // Disabled and card missing: the reason reported is the user's choice.
        val routing = resolveRouting(disabled, SdCardStatus.NotDetected, CacheFolderState.NotSelected)
        assertEquals(FallbackReason.DISABLED_BY_USER, routing.fallbackReason)
    }
}
