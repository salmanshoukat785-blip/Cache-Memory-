package com.sdcachemanager.domain

import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException

/** Every failure the app can report, with a message that is safe to show to the user. */
sealed class AppError(val message: String, val cause: Throwable? = null) {

    data object NoFolderSelected :
        AppError("No cache folder has been selected on the SD card.")

    data object SdCardUnavailable :
        AppError("The SD card is not available right now.")

    data object PermissionLost :
        AppError("Access to the selected folder was lost. Please select the folder again.")

    data object StorageFull :
        AppError("There is not enough free space to save this file.")

    class InvalidFolder(reason: String) : AppError(reason)

    class IoFailure(message: String, cause: Throwable? = null) : AppError(message, cause)
}

/** Maps a thrown exception to an [AppError]. */
fun Throwable.toAppError(): AppError = when (this) {
    is SecurityException -> AppError.PermissionLost
    is IOException -> {
        val text = message.orEmpty()
        if (text.contains("ENOSPC", ignoreCase = true) ||
            text.contains("No space left", ignoreCase = true)
        ) {
            AppError.StorageFull
        } else {
            AppError.IoFailure(text.ifBlank { "A storage error occurred." }, this)
        }
    }
    else -> AppError.IoFailure(message ?: "An unexpected error occurred.", this)
}

/** Success or a typed failure; used instead of throwing across layer boundaries. */
sealed interface CacheResult<out T> {
    data class Success<out T>(val value: T) : CacheResult<T>
    data class Failure(val error: AppError) : CacheResult<Nothing>
}

inline fun <T, R> CacheResult<T>.map(transform: (T) -> R): CacheResult<R> = when (this) {
    is CacheResult.Success -> CacheResult.Success(transform(value))
    is CacheResult.Failure -> this
}

fun <T> CacheResult<T>.getOrNull(): T? = (this as? CacheResult.Success)?.value

fun CacheResult<*>.errorOrNull(): AppError? = (this as? CacheResult.Failure)?.error

/**
 * Runs [block] and converts exceptions into [CacheResult.Failure].
 * Coroutine cancellation is always rethrown so structured concurrency keeps working.
 */
inline fun <T> cacheRunCatching(block: () -> T): CacheResult<T> = try {
    CacheResult.Success(block())
} catch (e: CancellationException) {
    throw e
} catch (e: Exception) {
    CacheResult.Failure(e.toAppError())
}
