package com.sdcachemanager

import android.app.Application
import android.content.Context
import com.sdcachemanager.data.CacheRepository
import com.sdcachemanager.data.SdCardDetector
import com.sdcachemanager.data.SettingsStore
import com.sdcachemanager.receiver.MediaReceiver

/**
 * Application entry point. Owns the dependency container and keeps a
 * [MediaReceiver] registered for as long as the process lives, so SD card
 * changes are noticed even while the UI is in the background.
 */
class SdCacheApp : Application() {

    lateinit var container: AppContainer
        private set

    private var mediaReceiver: MediaReceiver? = null

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        mediaReceiver = MediaReceiver { container.cacheRepository.requestRefresh() }
            .also { it.register(this) }
    }
}

/** Manual dependency container: simple, no framework, easy to replace with Hilt later. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val sdCardDetector = SdCardDetector(appContext)
    val settingsStore = SettingsStore(appContext)
    val cacheRepository = CacheRepository(appContext, sdCardDetector, settingsStore)
}
