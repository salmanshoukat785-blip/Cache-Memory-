package com.sdcachemanager.ui

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.sdcachemanager.SdCacheApp
import com.sdcachemanager.data.CacheRepository
import com.sdcachemanager.domain.CacheFileInfo
import com.sdcachemanager.domain.CacheResult
import com.sdcachemanager.domain.StorageMode
import com.sdcachemanager.domain.MoveReport
import com.sdcachemanager.domain.StorageSnapshot
import com.sdcachemanager.domain.formatBytes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** A one-off message for the snackbar. [id] makes two identical texts distinct events. */
data class UiMessage(val text: String, val id: Long)

data class CacheUiState(
    /** Null until the first storage check finishes. */
    val snapshot: StorageSnapshot? = null,
    val files: List<CacheFileInfo> = emptyList(),
    val isBusy: Boolean = false,
    val message: UiMessage? = null
)

class CacheViewModel(
    private val repository: CacheRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CacheUiState())
    val uiState: StateFlow<CacheUiState> = _uiState.asStateFlow()

    private var nextMessageId = 0L

    init {
        viewModelScope.launch {
            repository.snapshots.collect { snapshot ->
                _uiState.update { it.copy(snapshot = snapshot) }
                loadFiles()
            }
        }
    }

    /** Call when the screen becomes visible, in case a change happened while it was hidden. */
    fun onRefresh() = repository.requestRefresh()

    fun onFolderPicked(uri: Uri?) {
        if (uri == null) return // the user cancelled the picker
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true) }
            val result = repository.selectFolder(uri)
            val text = when (result) {
                is CacheResult.Success -> "Cache folder saved."
                is CacheResult.Failure -> result.error.message
            }
            _uiState.update { it.copy(isBusy = false, message = newMessage(text)) }
        }
    }

    fun onForgetFolder() {
        viewModelScope.launch {
            val text = when (val result = repository.forgetFolder()) {
                is CacheResult.Success -> "Folder forgotten. Files on the card were not touched."
                is CacheResult.Failure -> result.error.message
            }
            _uiState.update { it.copy(message = newMessage(text)) }
        }
    }

    fun onToggleEnabled(enabled: Boolean) {
        viewModelScope.launch {
            val result = repository.setSdCacheEnabled(enabled)
            if (result is CacheResult.Failure) {
                _uiState.update { it.copy(message = newMessage(result.error.message)) }
            }
        }
    }

    /** Writes a small file through the normal cache path so the user can see where it lands. */
    fun onWriteTestFile() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true) }
            val name = "test-${System.currentTimeMillis()}.tmp"
            val data = ByteArray(TEST_FILE_BYTES) { (it % 251).toByte() }
            val text = when (val result = repository.writeCacheBytes(name, data)) {
                is CacheResult.Success ->
                    if (result.value == StorageMode.SD_CARD) "Saved $name to the SD card."
                    else "Saved $name to internal storage."
                is CacheResult.Failure -> result.error.message
            }
            repository.requestRefresh()
            _uiState.update { it.copy(isBusy = false, message = newMessage(text)) }
        }
    }

    /** Only reached from an explicit confirmation by the user. */
    fun onDeleteFile(name: String) {
        viewModelScope.launch {
            val text = when (val result = repository.deleteCacheFile(name)) {
                is CacheResult.Success ->
                    if (result.value) "Deleted $name." else "$name was not found."
                is CacheResult.Failure -> result.error.message
            }
            _uiState.update { it.copy(message = newMessage(text)) }
            repository.requestRefresh()
        }
    }

    /** Copies fallback files back to the SD card. Only reached after the user confirms. */
    fun onMoveInternalFiles() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBusy = true) }
            val text = when (val result = repository.moveInternalFilesToSdCard()) {
                is CacheResult.Success -> result.value.summary()
                is CacheResult.Failure -> result.error.message
            }
            _uiState.update { it.copy(isBusy = false, message = newMessage(text)) }
        }
    }

    private fun MoveReport.summary(): String = buildString {
        append("Moved $moved file(s) to the SD card (${formatBytes(bytesMoved)}).")
        if (skippedExisting > 0) append(" $skippedExisting already existed there and were left in place.")
        if (failed > 0) append(" $failed could not be moved and were kept in internal storage.")
    }

    fun onMessageShown(id: Long) {
        _uiState.update { if (it.message?.id == id) it.copy(message = null) else it }
    }

    private suspend fun loadFiles() {
        val files = when (val result = repository.listCacheFiles()) {
            is CacheResult.Success -> result.value
            is CacheResult.Failure -> emptyList()
        }
        _uiState.update { it.copy(files = files) }
    }

    private fun newMessage(text: String) = UiMessage(text, nextMessageId++)

    companion object {
        private const val TEST_FILE_BYTES = 256 * 1024

        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val app = this[APPLICATION_KEY] as SdCacheApp
                CacheViewModel(app.container.cacheRepository)
            }
        }
    }
}
