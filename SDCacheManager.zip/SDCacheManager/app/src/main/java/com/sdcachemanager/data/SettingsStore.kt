package com.sdcachemanager.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.sdcachemanager.domain.AppSettings
import com.sdcachemanager.domain.CacheResult
import com.sdcachemanager.domain.cacheRunCatching
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

private val Context.settingsDataStore by preferencesDataStore(name = "sd_cache_settings")

/** Persists the enabled flag and the selected SAF folder URI using DataStore. */
class SettingsStore(context: Context) {

    private val dataStore = context.applicationContext.settingsDataStore

    /** Emits the current settings and every later change. A corrupt file falls back to defaults. */
    val settings: Flow<AppSettings> = dataStore.data
        .catch { e ->
            if (e is IOException) emit(emptyPreferences()) else throw e
        }
        .map { prefs -> prefs.toSettings() }

    suspend fun setEnabled(enabled: Boolean): CacheResult<Unit> = cacheRunCatching {
        dataStore.edit { it[KEY_ENABLED] = enabled }
        Unit
    }

    /** Pass null to forget the saved folder. */
    suspend fun setFolderUri(uri: String?): CacheResult<Unit> = cacheRunCatching {
        dataStore.edit { prefs ->
            if (uri == null) prefs.remove(KEY_FOLDER_URI) else prefs[KEY_FOLDER_URI] = uri
        }
        Unit
    }

    private fun Preferences.toSettings() = AppSettings(
        sdCacheEnabled = this[KEY_ENABLED] ?: true,
        folderUri = this[KEY_FOLDER_URI]
    )

    private companion object {
        val KEY_ENABLED = booleanPreferencesKey("sd_cache_enabled")
        val KEY_FOLDER_URI = stringPreferencesKey("folder_uri")
    }
}
