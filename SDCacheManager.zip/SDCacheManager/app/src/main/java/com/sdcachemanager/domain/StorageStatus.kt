package com.sdcachemanager.domain

import java.util.Locale

/** Total and free space of a storage volume, in bytes. */
data class StorageInfo(
    val totalBytes: Long,
    val freeBytes: Long
) {
    val usedBytes: Long get() = (totalBytes - freeBytes).coerceAtLeast(0L)

    /** 0f..1f; 0f when the total size is unknown. */
    val usedFraction: Float
        get() = if (totalBytes > 0L) (usedBytes.toFloat() / totalBytes).coerceIn(0f, 1f) else 0f

    companion object {
        val UNKNOWN = StorageInfo(totalBytes = 0L, freeBytes = 0L)
    }
}

/** What this app itself has stored in its cache location. */
data class CacheStats(
    val fileCount: Int,
    val totalBytes: Long
) {
    companion object {
        val EMPTY = CacheStats(fileCount = 0, totalBytes = 0L)
    }
}

/** A mounted removable volume (SD card). */
data class SdVolume(
    /** Human-readable name, e.g. "SD card". */
    val label: String,
    /**
     * Volume UUID such as "1A2B-3C4D". It appears in SAF tree URIs, which lets us
     * check that a saved folder really belongs to this card. May be null on some devices.
     */
    val uuid: String?,
    val storage: StorageInfo
)

/** Whether a removable SD card can be used right now. */
sealed interface SdCardStatus {

    /** No removable card is inserted or mounted. */
    data object NotDetected : SdCardStatus

    /** A card is present but cannot be written to (read-only, checking, unmounted, ...). */
    data class Unusable(val label: String?, val stateDescription: String) : SdCardStatus

    /** A mounted, writable card. */
    data class Available(val volume: SdVolume) : SdCardStatus
}

/**
 * State of the SAF folder the user selected for cache storage.
 * URIs are kept as plain strings so the domain layer stays free of Android types.
 */
sealed interface CacheFolderState {

    /** The user has not picked a folder yet. */
    data object NotSelected : CacheFolderState

    /** A folder is saved, still permitted, and reachable. */
    data class Ready(
        val uri: String,
        val displayName: String,
        val volumeUuid: String?
    ) : CacheFolderState

    /** A folder is saved but the persisted permission is gone. The user must pick it again. */
    data class PermissionLost(val uri: String) : CacheFolderState

    /** A folder is saved with permission, but cannot be opened right now (deleted, card removed). */
    data class Unreachable(val uri: String, val reason: String) : CacheFolderState
}

/** User preferences persisted by the app. */
data class AppSettings(
    /** Master switch: when false, the app only uses internal storage. */
    val sdCacheEnabled: Boolean = true,
    /** The SAF tree URI the user picked, or null if none. */
    val folderUri: String? = null
)

/** One file stored by this app in its cache. */
data class CacheFileInfo(
    val name: String,
    val sizeBytes: Long,
    val lastModified: Long,
    /** Which storage the file currently lives on. */
    val mode: StorageMode
)

/** Everything the UI needs to describe the current storage situation. */
data class StorageSnapshot(
    val settings: AppSettings,
    val sdCard: SdCardStatus,
    val folder: CacheFolderState,
    val routing: StorageRouting,
    /** Human-readable description of where new cache files are written right now. */
    val locationLabel: String,
    /** Space on the volume that is currently in use (SD card or internal). */
    val storage: StorageInfo,
    /** Size of this app's own cache at the active location. */
    val cacheStats: CacheStats,
    /** Files this app left in internal storage (e.g. written while the card was missing). */
    val internalFileCount: Int
)

/**
 * How much space one app uses, as Android's "App info" page reports it.
 * Android counts the cache as part of [dataBytes], so it is never added twice.
 */
data class AppStorage(
    /** Code: APK, optimized output and native libraries. */
    val appBytes: Long,
    /** All data, including the cache. */
    val dataBytes: Long,
    val cacheBytes: Long,
    /** Where the app is installed, e.g. "Internal storage" or "SD card". */
    val location: String
) {
    /** User data without the cache (the "Data" figure on the App info page). */
    val userDataBytes: Long get() = (dataBytes - cacheBytes).coerceAtLeast(0L)

    val totalBytes: Long get() = appBytes + dataBytes
}

/** Outcome of copying fallback files from internal storage back to the SD card. */
data class MoveReport(
    val moved: Int,
    /** Already on the SD card under the same name; the internal copy was left in place. */
    val skippedExisting: Int,
    /** Not moved because of an error (card removed or full, or the copy failed verification). */
    val failed: Int,
    val bytesMoved: Long
)

/** Formats a byte count using 1024-based units, e.g. "1.5 GB". */
fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unitIndex = -1
    while (value >= 1024.0 && unitIndex < units.lastIndex) {
        value /= 1024.0
        unitIndex++
    }
    return String.format(Locale.getDefault(), "%.1f %s", value, units[unitIndex])
}
