package com.sdcachemanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.sdcachemanager.ui.CacheScreen
import com.sdcachemanager.ui.theme.SdCacheManagerTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SdCacheManagerTheme {
                CacheScreen()
            }
        }
    }
}
