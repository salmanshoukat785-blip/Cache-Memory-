package com.sdcachemanager.data

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager
import com.sdcachemanager.domain.AppStorage
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.IOException
import java.util.UUID

/**
 * Reads how much space other apps use (app, data, cache), like Android's "App info" page.
 *
 * Android only allows this after the user grants "Usage access" to this app in Settings.
 * It reports sizes only: Android never lets an app look inside another app's data folder.
 */
class AppStorageReader(
    context: Context,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val appContext = context.applicationContext

    /** True once the user has allowed "Usage access" for this app. */
    @Suppress("DEPRECATION")
    fun hasUsageAccess(): Boolean {
        val appOps = appContext.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager
            ?: return false
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                appContext.packageName
            )
        } else {
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                appContext.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Sizes for every package that could be measured; others are simply missing from the map. */
    suspend fun readAll(packageNames: List<String>): Map<String, AppStorage> = withContext(ioDispatcher) {
        val volumes = candidateVolumes()
        val result = HashMap<String, AppStorage>()
        for (packageName in packageNames) {
            ensureActive()
            read(packageName, volumes)?.let { result[packageName] = it }
        }
        result
    }

    private data class Volume(val uuid: UUID, val label: String)

    /** Internal storage first, then any other volume (e.g. an SD card used as internal storage). */
    private fun candidateVolumes(): List<Volume> {
        val volumes = mutableListOf(Volume(StorageManager.UUID_DEFAULT, "Internal storage"))
        val storageManager = appContext.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
            ?: return volumes
        try {
            for (volume in storageManager.storageVolumes) {
                val uuid = volume.storageUuid ?: continue
                if (volumes.none { it.uuid == uuid }) {
                    val label = volume.getDescription(appContext)?.takeIf { it.isNotBlank() }
                        ?: "External storage"
                    volumes += Volume(uuid, label)
                }
            }
        } catch (e: SecurityException) {
            // Keep just internal storage.
        }
        return volumes
    }

    private fun read(packageName: String, volumes: List<Volume>): AppStorage? {
        val statsManager = appContext.getSystemService(Context.STORAGE_STATS_SERVICE) as? StorageStatsManager
            ?: return null
        for (volume in volumes) {
            try {
                val stats = statsManager.queryStatsForPackage(volume.uuid, packageName, Process.myUserHandle())
                return AppStorage(
                    appBytes = stats.appBytes,
                    dataBytes = stats.dataBytes,
                    cacheBytes = stats.cacheBytes,
                    location = volume.label
                )
            } catch (e: PackageManager.NameNotFoundException) {
                // Not on this volume; try the next one.
            } catch (e: IOException) {
                // Could not be measured on this volume; try the next one.
            } catch (e: SecurityException) {
                return null // Usage access was not granted (or was revoked).
            }
        }
        return null
    }
}
