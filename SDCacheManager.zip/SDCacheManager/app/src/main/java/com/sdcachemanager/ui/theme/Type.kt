package com.sdcachemanager.ui.theme

import androidx.compose.material3.Typography

/** Default Material 3 type scale; customize here when the design needs it. */
val AppTypography = Typography()
