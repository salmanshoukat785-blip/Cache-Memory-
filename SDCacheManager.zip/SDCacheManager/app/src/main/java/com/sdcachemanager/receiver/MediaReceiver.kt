package com.sdcachemanager.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat

/**
 * Listens for SD card mount / eject / removal broadcasts and calls [onStorageChanged].
 *
 * It is registered dynamically (see SdCacheApp) because Android 8+ does not deliver
 * these implicit broadcasts to receivers declared in the manifest. The receiver does no
 * work itself; it only asks the repository to re-check the real storage state.
 */
class MediaReceiver(
    private val onStorageChanged: () -> Unit
) : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action in ACTIONS) onStorageChanged()
    }

    fun register(context: Context) {
        val filter = IntentFilter().apply {
            ACTIONS.forEach { addAction(it) }
            addDataScheme("file") // required for the MEDIA_* broadcasts
        }
        ContextCompat.registerReceiver(
            context.applicationContext,
            this,
            filter,
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
    }

    fun unregister(context: Context) {
        try {
            context.applicationContext.unregisterReceiver(this)
        } catch (e: IllegalArgumentException) {
            // Not registered; nothing to do.
        }
    }

    private companion object {
        val ACTIONS = listOf(
            Intent.ACTION_MEDIA_MOUNTED,
            Intent.ACTION_MEDIA_UNMOUNTED,
            Intent.ACTION_MEDIA_REMOVED,
            Intent.ACTION_MEDIA_BAD_REMOVAL,
            Intent.ACTION_MEDIA_EJECT,
            Intent.ACTION_MEDIA_CHECKING,
            Intent.ACTION_MEDIA_UNMOUNTABLE,
            Intent.ACTION_MEDIA_NOFS,
            Intent.ACTION_MEDIA_SHARED
        )
    }
}
