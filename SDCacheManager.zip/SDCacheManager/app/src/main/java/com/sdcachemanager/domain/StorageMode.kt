package com.sdcachemanager.domain

/** Where the app's own cache/temp files are written right now. */
enum class StorageMode {
    /** The folder the user picked on the removable SD card (via SAF). */
    SD_CARD,

    /** The app's private internal cache directory (always available). */
    INTERNAL
}

/** Why the app is using internal storage instead of the SD card. */
enum class FallbackReason {
    /** The user turned SD card caching off. */
    DISABLED_BY_USER,

    /** SD card caching is on, but no folder has been chosen yet. */
    NO_FOLDER_SELECTED,

    /** No SD card is inserted/mounted (removed, ejected, or unmounted). */
    SD_CARD_MISSING,

    /** The card is present but read-only or otherwise unusable. */
    SD_CARD_UNUSABLE,

    /** The saved folder permission was revoked or can no longer be used. */
    PERMISSION_LOST,

    /** The saved folder no longer exists or cannot be opened. */
    FOLDER_UNREACHABLE
}

/**
 * The result of deciding where cache files go.
 * [fallbackReason] is null exactly when [mode] is [StorageMode.SD_CARD].
 */
data class StorageRouting(
    val mode: StorageMode,
    val fallbackReason: FallbackReason? = null
) {
    val isFallback: Boolean get() = mode == StorageMode.INTERNAL && fallbackReason != null
}

/**
 * Decides where new cache files go. Pure function, so it can be unit tested.
 *
 * The SD card is used only when every condition holds; the first failing condition
 * (in the order below) becomes the [FallbackReason] shown to the user.
 */
fun resolveRouting(
    settings: AppSettings,
    sdCard: SdCardStatus,
    folder: CacheFolderState
): StorageRouting {
    val reason = when {
        !settings.sdCacheEnabled -> FallbackReason.DISABLED_BY_USER
        sdCard is SdCardStatus.NotDetected -> FallbackReason.SD_CARD_MISSING
        sdCard is SdCardStatus.Unusable -> FallbackReason.SD_CARD_UNUSABLE
        folder is CacheFolderState.NotSelected -> FallbackReason.NO_FOLDER_SELECTED
        folder is CacheFolderState.PermissionLost -> FallbackReason.PERMISSION_LOST
        folder is CacheFolderState.Unreachable -> FallbackReason.FOLDER_UNREACHABLE
        else -> null
    }
    return if (reason == null) {
        StorageRouting(StorageMode.SD_CARD)
    } else {
        StorageRouting(StorageMode.INTERNAL, reason)
    }
}
