package com.sdcachemanager.data

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import android.os.storage.StorageVolume
import com.sdcachemanager.domain.SdCardStatus
import com.sdcachemanager.domain.SdVolume
import com.sdcachemanager.domain.StorageInfo
import java.io.File

/**
 * Detects a removable SD card using only public APIs (no permissions, no root).
 *
 * [detect] does blocking I/O (StatFs), so call it from a background dispatcher.
 *
 * Limitation: Android does not publicly distinguish an SD card from other removable
 * volumes such as a USB drive, so the first removable volume found is used.
 */
class SdCardDetector(context: Context) {

    private val appContext = context.applicationContext

    fun detect(): SdCardStatus {
        val storageManager = appContext.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
            ?: return SdCardStatus.NotDetected

        val volumes = try {
            storageManager.storageVolumes.filter { it.isRemovable }
        } catch (e: SecurityException) {
            return SdCardStatus.NotDetected
        }

        // Prefer a mounted volume if several removable volumes exist.
        val volume = volumes.firstOrNull { it.state == Environment.MEDIA_MOUNTED }
            ?: volumes.firstOrNull()
            ?: return SdCardStatus.NotDetected

        val label = volume.getDescription(appContext)?.takeIf { it.isNotBlank() } ?: "SD card"

        return when (volume.state) {
            Environment.MEDIA_MOUNTED -> SdCardStatus.Available(
                SdVolume(
                    label = label,
                    uuid = volume.uuid,
                    storage = readStorageInfo(volume) ?: StorageInfo.UNKNOWN
                )
            )
            Environment.MEDIA_MOUNTED_READ_ONLY ->
                SdCardStatus.Unusable(label, "The card is read-only.")
            Environment.MEDIA_CHECKING ->
                SdCardStatus.Unusable(label, "The card is being checked.")
            Environment.MEDIA_EJECTING ->
                SdCardStatus.Unusable(label, "The card is being ejected.")
            Environment.MEDIA_UNMOUNTED ->
                SdCardStatus.Unusable(label, "The card is not mounted.")
            Environment.MEDIA_NOFS, Environment.MEDIA_UNMOUNTABLE ->
                SdCardStatus.Unusable(label, "The card cannot be read (unsupported or damaged).")
            else -> SdCardStatus.NotDetected // removed, bad removal, unknown
        }
    }

    /**
     * Reads total/free space through this app's own external files directory on the volume,
     * which is always accessible without any permission.
     */
    private fun readStorageInfo(volume: StorageVolume): StorageInfo? {
        val dir = findAppDirOn(volume) ?: return null
        return try {
            val stat = StatFs(dir.path)
            StorageInfo(totalBytes = stat.totalBytes, freeBytes = stat.availableBytes)
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    private fun findAppDirOn(volume: StorageVolume): File? {
        val dirs = appContext.getExternalFilesDirs(null).filterNotNull()
        val uuid = volume.uuid
        if (uuid != null) {
            dirs.firstOrNull { it.path.contains(uuid, ignoreCase = true) }?.let { return it }
        }
        return dirs.firstOrNull { dir ->
            try {
                Environment.isExternalStorageRemovable(dir)
            } catch (e: IllegalArgumentException) {
                false
            }
        }
    }
}
