package com.sdcachemanager.ui.theme

import androidx.compose.ui.graphics.Color

// Light scheme
val LightPrimary = Color(0xFF006A6A)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFF9CF1F0)
val LightOnPrimaryContainer = Color(0xFF002020)
val LightSecondary = Color(0xFF4A6363)
val LightSecondaryContainer = Color(0xFFCCE8E7)
val LightOnSecondaryContainer = Color(0xFF051F1F)
val LightTertiary = Color(0xFF4B607C)
val LightTertiaryContainer = Color(0xFFD3E4FF)
val LightOnTertiaryContainer = Color(0xFF041C35)
val LightBackground = Color(0xFFF4FBFA)

// Dark scheme
val DarkPrimary = Color(0xFF4CDADA)
val DarkOnPrimary = Color(0xFF003737)
val DarkPrimaryContainer = Color(0xFF004F4F)
val DarkOnPrimaryContainer = Color(0xFF6FF7F6)
val DarkSecondary = Color(0xFFB0CCCB)
val DarkSecondaryContainer = Color(0xFF324B4B)
val DarkOnSecondaryContainer = Color(0xFFCCE8E7)
val DarkTertiary = Color(0xFFB3C8E8)
val DarkTertiaryContainer = Color(0xFF334863)
val DarkOnTertiaryContainer = Color(0xFFD3E4FF)
val DarkBackground = Color(0xFF0E1514)
val DarkOnBackground = Color(0xFFDDE4E3)
