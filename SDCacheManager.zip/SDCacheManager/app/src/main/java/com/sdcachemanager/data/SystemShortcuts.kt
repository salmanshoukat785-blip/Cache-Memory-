package com.sdcachemanager.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** An app the user can open the Android settings page for. */
data class InstalledApp(val label: String, val packageName: String)

/**
 * Shortcuts into Android's own settings screens.
 *
 * This app cannot move, format or redirect anything for other apps. These helpers only
 * open the system screens where the phone itself may offer those options.
 */
class SystemShortcuts(
    context: Context,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val appContext = context.applicationContext

    /**
     * The "Usage access" screen, where the user lets this app read other apps' storage sizes.
     * The first intent preselects this app; the second is the plain list for phones that
     * don't support that.
     */
    fun usageAccessIntents(): List<Intent> = listOf(
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.fromParts("package", appContext.packageName, null)),
        Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
    )

    /** The system "App info" page of [packageName]; its Storage section may offer "Change". */
    fun appDetailsIntent(packageName: String): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))

    /**
     * Apps that have a launcher icon, excluding this app. Uses the manifest <queries> entry
     * for launcher activities, so no broad "see all apps" permission is needed.
     */
    @Suppress("DEPRECATION")
    suspend fun listLaunchableApps(): List<InstalledApp> = withContext(ioDispatcher) {
        val pm = appContext.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(query, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            pm.queryIntentActivities(query, 0)
        }
        resolved
            .map { InstalledApp(label = it.loadLabel(pm).toString(), packageName = it.activityInfo.packageName) }
            .filter { it.packageName != appContext.packageName }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }
}
