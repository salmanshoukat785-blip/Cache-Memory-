package com.sdcachemanager.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.sdcachemanager.domain.CacheFileInfo
import com.sdcachemanager.domain.CacheFolderState
import com.sdcachemanager.domain.FallbackReason
import com.sdcachemanager.domain.SdCardStatus
import com.sdcachemanager.domain.StorageInfo
import com.sdcachemanager.domain.StorageMode
import com.sdcachemanager.domain.StorageSnapshot
import com.sdcachemanager.domain.formatBytes

/** Folder picker that also asks for a persistable read/write grant. */
class OpenCacheFolder : ActivityResultContracts.OpenDocumentTree() {
    override fun createIntent(context: Context, input: Uri?): Intent =
        super.createIntent(context, input).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CacheScreen(viewModel: CacheViewModel = viewModel(factory = CacheViewModel.Factory)) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val pickFolder = rememberLauncherForActivityResult(OpenCacheFolder()) { uri ->
        viewModel.onFolderPicked(uri)
    }

    // The card may have been removed or inserted while the app was in the background.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { viewModel.onRefresh() }

    LaunchedEffect(state.message) {
        state.message?.let { message ->
            snackbarHostState.showSnackbar(message.text)
            viewModel.onMessageShown(message.id)
        }
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("SD Cache Manager") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        val snapshot = state.snapshot
        if (snapshot == null) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            CacheContent(
                snapshot = snapshot,
                files = state.files,
                isBusy = state.isBusy,
                contentPadding = padding,
                onSelectFolder = { pickFolder.launch(null) },
                onForgetFolder = viewModel::onForgetFolder,
                onToggleEnabled = viewModel::onToggleEnabled,
                onWriteTestFile = viewModel::onWriteTestFile,
                onMoveInternalFiles = viewModel::onMoveInternalFiles,
                onDeleteFile = viewModel::onDeleteFile
            )
        }
    }
}

@Composable
private fun CacheContent(
    snapshot: StorageSnapshot,
    files: List<CacheFileInfo>,
    isBusy: Boolean,
    contentPadding: PaddingValues,
    onSelectFolder: () -> Unit,
    onForgetFolder: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit,
    onWriteTestFile: () -> Unit,
    onMoveInternalFiles: () -> Unit,
    onDeleteFile: (String) -> Unit
) {
    var pendingDelete by remember { mutableStateOf<String?>(null) }
    var confirmMove by remember { mutableStateOf(false) }

    Box(modifier = Modifier.padding(contentPadding)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { StatusBanner(snapshot) }
            item { SdCardCard(snapshot.sdCard) }
            item {
                CacheLocationCard(
                    snapshot = snapshot,
                    isBusy = isBusy,
                    onSelectFolder = onSelectFolder,
                    onForgetFolder = onForgetFolder,
                    onToggleEnabled = onToggleEnabled
                )
            }
            item {
                CacheUsageCard(
                    snapshot = snapshot,
                    isBusy = isBusy,
                    onWriteTestFile = onWriteTestFile,
                    onMove = { confirmMove = true }
                )
            }

            item {
                Text(
                    text = "Cache files",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
            if (files.isEmpty()) {
                item {
                    Text(
                        text = "No cache files yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(files.take(MAX_LISTED_FILES), key = { "${it.mode}:${it.name}" }) { file ->
                    FileRow(file = file, onDelete = { pendingDelete = file.name })
                }
                if (files.size > MAX_LISTED_FILES) {
                    item {
                        Text(
                            text = "Showing $MAX_LISTED_FILES of ${files.size} files.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { AboutCard() }
        }

        pendingDelete?.let { name ->
            AlertDialog(
                onDismissRequest = { pendingDelete = null },
                title = { Text("Delete file?") },
                text = { Text("\"$name\" will be removed from this app's cache. No other files are affected.") },
                confirmButton = {
                    TextButton(onClick = {
                        onDeleteFile(name)
                        pendingDelete = null
                    }) { Text("Delete") }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDelete = null }) { Text("Cancel") }
                }
            )
        }

        if (confirmMove) {
            AlertDialog(
                onDismissRequest = { confirmMove = false },
                title = { Text("Move files to SD card?") },
                text = {
                    Text(
                        "Each file is copied to the SD card and checked. The internal copy is removed " +
                            "only after the copy is verified. Files that already exist on the card are left alone."
                    )
                },
                confirmButton = {
                    TextButton(onClick = {
                        onMoveInternalFiles()
                        confirmMove = false
                    }) { Text("Move") }
                },
                dismissButton = {
                    TextButton(onClick = { confirmMove = false }) { Text("Cancel") }
                }
            )
        }
    }
}

private const val MAX_LISTED_FILES = 100

// ------------------------------------------------------------------------ sections

@Composable
private fun StatusBanner(snapshot: StorageSnapshot) {
    val onSd = snapshot.routing.mode == StorageMode.SD_CARD
    val colors = MaterialTheme.colorScheme
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (onSd) colors.primaryContainer else colors.tertiaryContainer,
            contentColor = if (onSd) colors.onPrimaryContainer else colors.onTertiaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(
                imageVector = if (onSd) Icons.Filled.SdCard else Icons.Filled.PhoneAndroid,
                contentDescription = null,
                modifier = Modifier.size(32.dp)
            )
            Column {
                Text(
                    text = if (onSd) "Using SD card" else "Using internal storage",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = snapshot.routing.fallbackReason?.explanation()
                        ?: "New cache files are saved to your SD card folder.",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun SdCardCard(sd: SdCardStatus) {
    SectionCard(title = "SD card", icon = Icons.Filled.SdCard) {
        when (sd) {
            is SdCardStatus.NotDetected -> {
                InfoLine("Status", "Not detected")
            }
            is SdCardStatus.Unusable -> {
                InfoLine("Status", "Unavailable")
                sd.label?.let { InfoLine("Card", it) }
                Text(
                    text = sd.stateDescription,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            is SdCardStatus.Available -> {
                InfoLine("Status", "Ready")
                InfoLine("Card", sd.volume.label)
                StorageBar(sd.volume.storage)
            }
        }
    }
}

@Composable
private fun CacheLocationCard(
    snapshot: StorageSnapshot,
    isBusy: Boolean,
    onSelectFolder: () -> Unit,
    onForgetFolder: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit
) {
    val cardReady = snapshot.sdCard is SdCardStatus.Available
    val hasFolder = snapshot.folder !is CacheFolderState.NotSelected

    SectionCard(title = "Cache location", icon = Icons.Filled.FolderOpen) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Use SD card for cache", style = MaterialTheme.typography.titleSmall)
                Text(
                    text = "Turn off to use internal storage only.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = snapshot.settings.sdCacheEnabled,
                onCheckedChange = onToggleEnabled
            )
        }

        HorizontalDivider()

        InfoLine("Selected folder", folderText(snapshot.folder))
        InfoLine("Writing to", snapshot.locationLabel)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onSelectFolder, enabled = cardReady && !isBusy) {
                Text(if (hasFolder) "Change folder" else "Select folder")
            }
            if (hasFolder) {
                TextButton(onClick = onForgetFolder, enabled = !isBusy) { Text("Forget") }
            }
        }

        val hint = when {
            !cardReady -> "Insert an SD card to choose a folder."
            !hasFolder ->
                "Choose or create a folder on the SD card. Recent Android versions don't allow the top level of the card, so create a subfolder such as \"Cache\"."
            else -> null
        }
        hint?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun CacheUsageCard(
    snapshot: StorageSnapshot,
    isBusy: Boolean,
    onWriteTestFile: () -> Unit,
    onMove: () -> Unit
) {
    SectionCard(title = "Cache usage", icon = Icons.Filled.Storage) {
        InfoLine("Files", snapshot.cacheStats.fileCount.toString())
        InfoLine("Size", formatBytes(snapshot.cacheStats.totalBytes))
        InfoLine(
            "Free space here",
            if (snapshot.storage.totalBytes > 0L) formatBytes(snapshot.storage.freeBytes) else "Unknown"
        )

        if (snapshot.routing.mode == StorageMode.SD_CARD && snapshot.internalFileCount > 0) {
            Text(
                text = "${snapshot.internalFileCount} file(s) are still in internal storage from a time " +
                    "the SD card was unavailable. They stay readable, and nothing is moved unless you choose to.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            FilledTonalButton(onClick = onMove, enabled = !isBusy) {
                Text("Move ${snapshot.internalFileCount} file(s) to SD card")
            }
        }

        FilledTonalButton(onClick = onWriteTestFile, enabled = !isBusy) {
            Text("Write test cache file (256 KB)")
        }
    }
}

@Composable
private fun FileRow(file: CacheFileInfo, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        ListItem(
            headlineContent = { Text(file.name) },
            supportingContent = {
                val where = if (file.mode == StorageMode.SD_CARD) "SD card" else "Internal"
                Text("${formatBytes(file.sizeBytes)} · $where")
            },
            trailingContent = {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete ${file.name}")
                }
            },
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
    }
}

@Composable
private fun AboutCard() {
    SectionCard(title = "About", icon = Icons.Filled.Info) {
        Text(
            text = "SD Cache Manager controls only where this app's own cache and temporary files are " +
                "stored. Android does not allow apps to move or redirect the cache of other apps, and " +
                "no root access is used.",
            style = MaterialTheme.typography.bodySmall
        )
        Text(
            text = "Android doesn't distinguish SD cards from other removable storage, so a USB drive " +
                "may be shown as the SD card.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

// ------------------------------------------------------------------------ building blocks

@Composable
private fun SectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }
            content()
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(16.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.End,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun StorageBar(info: StorageInfo) {
    if (info.totalBytes > 0L) {
        LinearProgressIndicator(
            progress = { info.usedFraction },
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
        Text(
            text = "${formatBytes(info.usedBytes)} used of ${formatBytes(info.totalBytes)} · " +
                "${formatBytes(info.freeBytes)} free",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    } else {
        Text(
            text = "Space information is unavailable.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun folderText(folder: CacheFolderState): String = when (folder) {
    is CacheFolderState.NotSelected -> "None"
    is CacheFolderState.Ready -> folder.displayName
    is CacheFolderState.PermissionLost -> "Access lost – select again"
    is CacheFolderState.Unreachable -> "Unavailable (${folder.reason})"
}

private fun FallbackReason.explanation(): String = when (this) {
    FallbackReason.DISABLED_BY_USER -> "SD card caching is turned off."
    FallbackReason.NO_FOLDER_SELECTED -> "Select a folder on the SD card to start using it."
    FallbackReason.SD_CARD_MISSING ->
        "No SD card detected. Files are saved internally until it returns."
    FallbackReason.SD_CARD_UNUSABLE -> "The SD card can't be written to right now."
    FallbackReason.PERMISSION_LOST -> "Access to the folder was lost. Select the folder again."
    FallbackReason.FOLDER_UNREACHABLE ->
        "The saved folder can't be opened. Re-insert the card or select another folder."
}
