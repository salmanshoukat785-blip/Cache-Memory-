package com.sdcachemanager.data

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.StatFs
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import com.sdcachemanager.domain.AppError
import com.sdcachemanager.domain.AppSettings
import com.sdcachemanager.domain.CacheFileInfo
import com.sdcachemanager.domain.CacheFolderState
import com.sdcachemanager.domain.CacheResult
import com.sdcachemanager.domain.CacheStats
import com.sdcachemanager.domain.SdCardStatus
import com.sdcachemanager.domain.StorageInfo
import com.sdcachemanager.domain.StorageMode
import com.sdcachemanager.domain.StorageRouting
import com.sdcachemanager.domain.StorageSnapshot
import com.sdcachemanager.domain.cacheRunCatching
import com.sdcachemanager.domain.map
import com.sdcachemanager.domain.MoveReport
import com.sdcachemanager.domain.resolveRouting
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/** Folder created inside the folder the user picked; the app only ever touches this subfolder. */
private const val CACHE_SUBDIR = "SDCacheManager"
private const val INTERNAL_SUBDIR = "managed_cache"
private const val PART_SUFFIX = ".part"
private const val EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents"
private const val PERSIST_FLAGS =
    Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION

/**
 * Single place that decides where this app's own cache files go and performs the I/O.
 *
 * - New files go to the SD card folder when it is enabled, permitted and reachable;
 *   otherwise to internal storage. The decision is re-made on every operation, so the
 *   app switches back to the SD card automatically once it is available again.
 * - Only a dedicated subfolder ("SDCacheManager") inside the user's chosen folder is
 *   used, and nothing is ever deleted automatically.
 * - This only manages this app's own files. It does not touch other apps' caches.
 */
class CacheRepository(
    context: Context,
    private val detector: SdCardDetector,
    private val settingsStore: SettingsStore,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO
) {
    private val appContext = context.applicationContext
    private val resolver: ContentResolver get() = appContext.contentResolver
    private val refreshTicks = MutableStateFlow(0)

    /** Emits a fresh snapshot on every settings change and every [requestRefresh]. */
    val snapshots: Flow<StorageSnapshot> =
        combine(settingsStore.settings, refreshTicks) { settings, _ -> settings }
            .map { settings -> buildSnapshot(resolve(settings)) }
            .flowOn(ioDispatcher)
            .conflate()

    /** Re-checks the SD card and folder (call on mount/eject events and on app resume). */
    fun requestRefresh() {
        refreshTicks.update { it + 1 }
    }

    // ---------------------------------------------------------------- settings / folder

    suspend fun setSdCacheEnabled(enabled: Boolean): CacheResult<Unit> =
        settingsStore.setEnabled(enabled)

    /**
     * Validates the folder returned by the system folder picker, takes persistable
     * read/write permission for it, and saves it.
     */
    suspend fun selectFolder(uri: Uri): CacheResult<Unit> = withContext(ioDispatcher) {
        val sd = try {
            detector.detect()
        } catch (e: Exception) {
            SdCardStatus.NotDetected
        }
        validatePickedFolder(uri, sd)?.let { return@withContext CacheResult.Failure(it) }

        val taken = cacheRunCatching { resolver.takePersistableUriPermission(uri, PERSIST_FLAGS) }
        if (taken is CacheResult.Failure) return@withContext taken

        val usable = try {
            DocumentFile.fromTreeUri(appContext, uri)?.let { it.isDirectory && it.canWrite() } ?: false
        } catch (e: Exception) {
            false
        }
        if (!usable) {
            releaseQuietly(uri)
            return@withContext CacheResult.Failure(AppError.InvalidFolder("The selected folder is not writable."))
        }

        // Free the permission slot of a previously saved, different folder.
        val previous = settingsStore.settings.first().folderUri
        if (previous != null && previous != uri.toString()) releaseQuietly(Uri.parse(previous))

        val saved = settingsStore.setFolderUri(uri.toString())
        requestRefresh()
        saved
    }

    /** Forgets the saved folder and releases its permission. Files on the card are left untouched. */
    suspend fun forgetFolder(): CacheResult<Unit> = withContext(ioDispatcher) {
        settingsStore.settings.first().folderUri?.let { releaseQuietly(Uri.parse(it)) }
        val saved = settingsStore.setFolderUri(null)
        requestRefresh()
        saved
    }

    // ---------------------------------------------------------------- cache file operations

    /**
     * Writes a cache file and reports where it ended up.
     *
     * If the SD card write fails (e.g. the card was just removed), the write is retried on
     * internal storage and the result is [StorageMode.INTERNAL]. Because of that retry,
     * [writer] must be safe to run twice; use [writeCacheBytes] for in-memory data.
     */
    suspend fun writeCacheFile(
        name: String,
        writer: (OutputStream) -> Unit
    ): CacheResult<StorageMode> = withContext(ioDispatcher) {
        validateName(name)?.let { return@withContext CacheResult.Failure(it) }
        val resolved = resolve(settingsStore.settings.first())

        if (resolved.routing.mode == StorageMode.SD_CARD) {
            val sdWrite = cacheRunCatching { activeBackend(resolved).write(name, writer) }
            if (sdWrite is CacheResult.Success) return@withContext CacheResult.Success(StorageMode.SD_CARD)
            requestRefresh() // the card or folder probably went away; update the UI state
        }

        cacheRunCatching { internalBackend().write(name, writer) }.map { StorageMode.INTERNAL }
    }

    suspend fun writeCacheBytes(name: String, data: ByteArray): CacheResult<StorageMode> =
        writeCacheFile(name) { it.write(data) }

    /** Reads a file from the active location, then from internal storage (fallback leftovers). */
    suspend fun readCacheFile(name: String): CacheResult<ByteArray?> = withContext(ioDispatcher) {
        validateName(name)?.let { return@withContext CacheResult.Failure(it) }
        val resolved = resolve(settingsStore.settings.first())

        var firstError: CacheResult.Failure? = null
        for (backend in readOrder(resolved)) {
            when (val result = cacheRunCatching { backend.read(name) }) {
                is CacheResult.Success -> if (result.value != null) return@withContext result
                is CacheResult.Failure -> if (firstError == null) firstError = result
            }
        }
        firstError ?: CacheResult.Success(null)
    }

    /** Lists this app's cache files on the active location and in internal storage. */
    suspend fun listCacheFiles(): CacheResult<List<CacheFileInfo>> = withContext(ioDispatcher) {
        val resolved = resolve(settingsStore.settings.first())

        val all = mutableListOf<CacheFileInfo>()
        var firstError: CacheResult.Failure? = null
        for (backend in readOrder(resolved)) {
            when (val result = cacheRunCatching { backend.list() }) {
                is CacheResult.Success -> all += result.value
                is CacheResult.Failure -> if (firstError == null) firstError = result
            }
        }
        if (all.isEmpty() && firstError != null) firstError
        else CacheResult.Success(all.sortedBy { it.name.lowercase() })
    }

    /**
     * Deletes one named cache file. Only call this from an explicit user action;
     * the app never deletes anything on its own.
     */
    suspend fun deleteCacheFile(name: String): CacheResult<Boolean> = withContext(ioDispatcher) {
        validateName(name)?.let { return@withContext CacheResult.Failure(it) }
        val resolved = resolve(settingsStore.settings.first())

        var firstError: CacheResult.Failure? = null
        for (backend in readOrder(resolved)) {
            when (val result = cacheRunCatching { backend.delete(name) }) {
                is CacheResult.Success -> if (result.value) {
                    requestRefresh()
                    return@withContext result
                }
                is CacheResult.Failure -> if (firstError == null) firstError = result
            }
        }
        firstError ?: CacheResult.Success(false)
    }

    /**
     * Copies files left in internal storage (from times the card was unavailable) to the SD card.
     *
     * Only runs when the SD card is currently in use, and only from an explicit user action.
     * For each file: copy, verify the size on the card, and only then remove the internal copy.
     * Files that already exist on the card are never overwritten. On the first error
     * (card removed, card full, failed verification) it stops and keeps every remaining
     * internal original.
     */
    suspend fun moveInternalFilesToSdCard(): CacheResult<MoveReport> = withContext(ioDispatcher) {
        val resolved = resolve(settingsStore.settings.first())
        if (resolved.routing.mode != StorageMode.SD_CARD) {
            return@withContext CacheResult.Failure(AppError.SdCardUnavailable)
        }

        val result = cacheRunCatching {
            val sd = activeBackend(resolved)
            val internal = internalBackend()
            val files = internal.list()

            var moved = 0
            var skipped = 0
            var bytesMoved = 0L
            for (file in files) {
                ensureActive()
                if (sd.sizeOf(file.name) != null) {
                    skipped++
                    continue
                }
                val size = internal.sizeOf(file.name) ?: continue
                val copied = try {
                    copyVerified(internal, sd, file.name, size)
                } catch (e: Exception) {
                    false
                }
                if (!copied) break
                if (internal.delete(file.name)) {
                    moved++
                    bytesMoved += size
                }
            }
            MoveReport(
                moved = moved,
                skippedExisting = skipped,
                failed = files.size - moved - skipped,
                bytesMoved = bytesMoved
            )
        }
        requestRefresh()
        result
    }

    private fun copyVerified(
        source: CacheBackend,
        dest: CacheBackend,
        name: String,
        expectedSize: Long
    ): Boolean {
        val input = source.open(name) ?: return false
        input.use { stream -> dest.write(name) { out -> stream.copyTo(out) } }
        if (dest.sizeOf(name) == expectedSize) return true
        // The name did not exist on the destination before, so this is our own bad copy.
        dest.delete(name)
        return false
    }

    // ---------------------------------------------------------------- state resolution

    private data class Resolved(
        val settings: AppSettings,
        val sdCard: SdCardStatus,
        val folder: CacheFolderState,
        val routing: StorageRouting
    )

    private fun resolve(settings: AppSettings): Resolved {
        val sd = try {
            detector.detect()
        } catch (e: Exception) {
            SdCardStatus.NotDetected
        }
        val folder = evaluateFolder(settings.folderUri, sd)
        return Resolved(settings, sd, folder, resolveRouting(settings, sd, folder))
    }

    private fun evaluateFolder(folderUri: String?, sd: SdCardStatus): CacheFolderState {
        if (folderUri == null) return CacheFolderState.NotSelected
        val uri = Uri.parse(folderUri)

        val permitted = resolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission && it.isWritePermission
        }
        if (!permitted) return CacheFolderState.PermissionLost(folderUri)

        // Don't query the document provider while the card is missing; it would only fail.
        if (sd !is SdCardStatus.Available) {
            return CacheFolderState.Unreachable(folderUri, "The SD card is not available.")
        }

        val volumeId = volumeIdOf(uri)
        val cardUuid = sd.volume.uuid
        if (cardUuid != null && volumeId != null && !volumeId.equals(cardUuid, ignoreCase = true)) {
            return CacheFolderState.Unreachable(folderUri, "The saved folder belongs to a different card.")
        }

        return try {
            val doc = DocumentFile.fromTreeUri(appContext, uri)
            when {
                doc == null || !doc.exists() ->
                    CacheFolderState.Unreachable(folderUri, "The folder could not be found.")
                !doc.isDirectory || !doc.canWrite() ->
                    CacheFolderState.Unreachable(folderUri, "The folder is not writable.")
                else ->
                    CacheFolderState.Ready(folderUri, doc.name ?: "Selected folder", volumeId)
            }
        } catch (e: SecurityException) {
            CacheFolderState.PermissionLost(folderUri)
        } catch (e: Exception) {
            CacheFolderState.Unreachable(folderUri, e.message ?: "The folder could not be opened.")
        }
    }

    private fun validatePickedFolder(uri: Uri, sd: SdCardStatus): AppError? {
        if (sd !is SdCardStatus.Available) return AppError.SdCardUnavailable
        if (uri.authority != EXTERNAL_STORAGE_AUTHORITY) {
            return AppError.InvalidFolder("Please choose a folder on the SD card.")
        }
        val volumeId = volumeIdOf(uri)
            ?: return AppError.InvalidFolder("That folder cannot be used.")
        if (volumeId.equals("primary", ignoreCase = true)) {
            return AppError.InvalidFolder("That folder is on internal storage. Please choose a folder on the SD card.")
        }
        val cardUuid = sd.volume.uuid
        if (cardUuid != null && !volumeId.equals(cardUuid, ignoreCase = true)) {
            return AppError.InvalidFolder("That folder is not on the detected SD card.")
        }
        return null
    }

    /** "1A2B-3C4D" from a tree URI whose document id is "1A2B-3C4D:Some/Folder". */
    private fun volumeIdOf(uri: Uri): String? = try {
        DocumentsContract.getTreeDocumentId(uri)
            .substringBefore(':', missingDelimiterValue = "")
            .ifEmpty { null }
    } catch (e: IllegalArgumentException) {
        null
    }

    private fun releaseQuietly(uri: Uri) {
        try {
            resolver.releasePersistableUriPermission(uri, PERSIST_FLAGS)
        } catch (e: SecurityException) {
            // The permission was not held; nothing to release.
        }
    }

    // ---------------------------------------------------------------- snapshot

    private fun buildSnapshot(r: Resolved): StorageSnapshot {
        val backend = activeBackend(r)
        val files = try {
            backend.list()
        } catch (e: Exception) {
            emptyList()
        }
        val stats = CacheStats(files.size, files.sumOf { it.sizeBytes })
        val internalCount = if (backend.mode == StorageMode.INTERNAL) {
            files.size
        } else {
            try {
                internalBackend().list().size
            } catch (e: Exception) {
                0
            }
        }

        val sdVolume = (r.sdCard as? SdCardStatus.Available)?.volume
        val folder = r.folder
        val (storage, label) =
            if (backend.mode == StorageMode.SD_CARD && sdVolume != null && folder is CacheFolderState.Ready) {
                sdVolume.storage to "${sdVolume.label} › ${folder.displayName}/$CACHE_SUBDIR"
            } else {
                internalStorageInfo() to "Internal storage (app cache)"
            }

        return StorageSnapshot(
            settings = r.settings,
            sdCard = r.sdCard,
            folder = r.folder,
            routing = r.routing,
            locationLabel = label,
            storage = storage,
            cacheStats = stats,
            internalFileCount = internalCount
        )
    }

    private fun internalStorageInfo(): StorageInfo = try {
        val stat = StatFs(appContext.cacheDir.path)
        StorageInfo(totalBytes = stat.totalBytes, freeBytes = stat.availableBytes)
    } catch (e: IllegalArgumentException) {
        StorageInfo.UNKNOWN
    }

    // ---------------------------------------------------------------- backends

    private fun internalBackend(): CacheBackend =
        InternalBackend(File(appContext.cacheDir, INTERNAL_SUBDIR))

    private fun activeBackend(r: Resolved): CacheBackend {
        val folder = r.folder
        return if (r.routing.mode == StorageMode.SD_CARD && folder is CacheFolderState.Ready) {
            SafBackend(appContext, Uri.parse(folder.uri))
        } else {
            internalBackend()
        }
    }

    /** Active location first, then internal storage so fallback files stay reachable. */
    private fun readOrder(r: Resolved): List<CacheBackend> {
        val active = activeBackend(r)
        return if (active.mode == StorageMode.INTERNAL) listOf(active) else listOf(active, internalBackend())
    }

    private fun validateName(name: String): AppError? = when {
        name.isBlank() -> AppError.IoFailure("The file name is empty.")
        name.length > 200 -> AppError.IoFailure("The file name is too long.")
        name == "." || name == ".." || name.any { it == '/' || it == '\\' || it == '\u0000' } ->
            AppError.IoFailure("The file name contains invalid characters.")
        name.endsWith(PART_SUFFIX) -> AppError.IoFailure("File names ending in \"$PART_SUFFIX\" are reserved.")
        else -> null
    }
}

// -------------------------------------------------------------------- backend types

private interface CacheBackend {
    val mode: StorageMode
    fun write(name: String, writer: (OutputStream) -> Unit)
    fun read(name: String): ByteArray?
    fun list(): List<CacheFileInfo>
    fun delete(name: String): Boolean

    /** Opens a stream to read the file, or null if it does not exist. Caller closes it. */
    fun open(name: String): InputStream?

    /** Size in bytes, or null if the file does not exist. */
    fun sizeOf(name: String): Long?
}

/** Plain java.io access to the app's private cache directory. */
private class InternalBackend(private val dir: File) : CacheBackend {
    override val mode = StorageMode.INTERNAL

    private fun ensureDir(): File {
        if (!dir.isDirectory && !dir.mkdirs()) throw IOException("Could not create the internal cache folder.")
        return dir
    }

    override fun write(name: String, writer: (OutputStream) -> Unit) {
        val folder = ensureDir()
        val temp = File(folder, name + PART_SUFFIX)
        try {
            temp.outputStream().use { writer(it) }
            if (!temp.renameTo(File(folder, name))) throw IOException("Could not save \"$name\".")
        } catch (e: Exception) {
            temp.delete()
            throw e
        }
    }

    override fun read(name: String): ByteArray? {
        val file = File(dir, name)
        return if (file.isFile) file.readBytes() else null
    }

    override fun list(): List<CacheFileInfo> =
        dir.listFiles().orEmpty()
            .filter { it.isFile && !it.name.endsWith(PART_SUFFIX) }
            .map { CacheFileInfo(it.name, it.length(), it.lastModified(), StorageMode.INTERNAL) }

    override fun delete(name: String): Boolean {
        val file = File(dir, name)
        return file.isFile && file.delete()
    }

    override fun open(name: String): InputStream? =
        File(dir, name).takeIf { it.isFile }?.inputStream()

    override fun sizeOf(name: String): Long? =
        File(dir, name).takeIf { it.isFile }?.length()
}

/**
 * Storage Access Framework access to the "SDCacheManager" subfolder inside the folder
 * the user picked. Any failure (card removed, permission revoked) surfaces as an exception
 * that the repository turns into a fallback.
 */
private class SafBackend(
    private val context: Context,
    private val treeUri: Uri
) : CacheBackend {
    override val mode = StorageMode.SD_CARD

    private val resolver: ContentResolver get() = context.contentResolver

    private fun root(): DocumentFile {
        val root = DocumentFile.fromTreeUri(context, treeUri)
        if (root == null || !root.exists() || !root.isDirectory) {
            throw FileNotFoundException("The SD card folder is not available.")
        }
        return root
    }

    private fun findCacheDir(): DocumentFile? {
        val existing = root().findFile(CACHE_SUBDIR) ?: return null
        if (!existing.isDirectory) throw IOException("A file named \"$CACHE_SUBDIR\" blocks the cache folder.")
        return existing
    }

    private fun ensureCacheDir(): DocumentFile =
        findCacheDir()
            ?: root().createDirectory(CACHE_SUBDIR)
            ?: throw IOException("Could not create the cache folder on the SD card.")

    override fun write(name: String, writer: (OutputStream) -> Unit) {
        val dir = ensureCacheDir()
        val existing = dir.findFile(name)
        val target = existing
            ?: dir.createFile("application/octet-stream", name)
            ?: throw IOException("Could not create \"$name\" on the SD card.")
        try {
            val output = resolver.openOutputStream(target.uri, "wt")
                ?: throw IOException("Could not open \"$name\" for writing.")
            output.use { writer(it) }
        } catch (e: Exception) {
            // Remove only a half-written file that this call created.
            if (existing == null) {
                try {
                    target.delete()
                } catch (ignored: Exception) {
                }
            }
            throw e
        }
    }

    override fun read(name: String): ByteArray? {
        val file = findCacheDir()?.findFile(name) ?: return null
        if (!file.isFile) return null
        return resolver.openInputStream(file.uri)?.use { it.readBytes() }
    }

    override fun list(): List<CacheFileInfo> {
        val files = findCacheDir()?.listFiles() ?: return emptyList()
        return files
            .filter { it.isFile }
            .mapNotNull { file ->
                file.name?.let { CacheFileInfo(it, file.length(), file.lastModified(), StorageMode.SD_CARD) }
            }
    }

    override fun delete(name: String): Boolean {
        val file = findCacheDir()?.findFile(name) ?: return false
        return file.isFile && file.delete()
    }

    override fun open(name: String): InputStream? {
        val file = findCacheDir()?.findFile(name)?.takeIf { it.isFile } ?: return null
        return resolver.openInputStream(file.uri)
    }

    override fun sizeOf(name: String): Long? =
        findCacheDir()?.findFile(name)?.takeIf { it.isFile }?.length()
}
