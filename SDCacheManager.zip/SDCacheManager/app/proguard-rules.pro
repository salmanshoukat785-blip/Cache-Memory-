# Default ProGuard/R8 rules. Minification is disabled in this version.
